import os
import re
import logging
import time
import shutil
import requests
import m3u8
import ffmpeg
from urllib.parse import urljoin

logger = logging.getLogger(__name__)

class M3U8Downloader:
    def __init__(self, download_dir):
        self.download_dir = download_dir
        os.makedirs(download_dir, exist_ok=True)
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })

    def clean_expired_files(self, hours=24):
        """清理超过指定小时数的文件"""
        if not os.path.exists(self.download_dir):
            return 0
            
        now = time.time()
        total_cleaned = 0
        
        for filename in os.listdir(self.download_dir):
            file_path = os.path.join(self.download_dir, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    file_age = now - os.path.getmtime(file_path)
                    if file_age > hours * 3600:
                        file_size = os.path.getsize(file_path)
                        total_cleaned += file_size
                        os.unlink(file_path)
                        logger.info(f"删除过期文件: {file_path}")
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
                    logger.info(f"删除过期目录: {file_path}")
            except Exception as e:
                logger.error(f"清理文件时出错 {file_path}: {e}")
                
        return total_cleaned / (1024 * 1024)  # 转换为MB

    def get_cache_size(self):
        """获取缓存总大小（MB）"""
        total_size = 0
        for dirpath, _, filenames in os.walk(self.download_dir):
            for f in filenames:
                fp = os.path.join(dirpath, f)
                if os.path.exists(fp):
                    total_size += os.path.getsize(fp)
        return total_size / (1024 * 1024)

    def delete_file(self, file_path):
        """删除文件，包含错误处理"""
        try:
            if os.path.exists(file_path):
                if os.path.isfile(file_path):
                    os.remove(file_path)
                    logger.info(f"已删除文件: {file_path}")
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
                    logger.info(f"已删除目录: {file_path}")
            return True
        except Exception as e:
            logger.error(f"删除文件失败 {file_path}: {e}")
            return False

    def update_status(self, status_msg, context, text):
        """更新状态消息，处理可能的错误"""
        try:
            context.bot.edit_message_text(
                chat_id=status_msg.chat_id,
                message_id=status_msg.message_id,
                text=text
            )
        except Exception as e:
            logger.warning(f"更新状态消息失败: {str(e)}")

    def download_m3u8(self, url, status_msg, context):
        """下载M3U8视频并转换为MP4"""
        try:
            # 创建唯一的临时目录
            temp_dir = os.path.join(self.download_dir, f"temp_{int(time.time())}")
            os.makedirs(temp_dir, exist_ok=True)
            
            # 更新状态
            self.update_status(status_msg, context, "正在解析M3U8文件...")
            
            # 下载并解析M3U8
            m3u8_obj = self._get_m3u8_playlist(url)
            if not m3u8_obj:
                return None, "无法解析M3U8文件"
                
            # 获取TS片段列表
            ts_urls = self._get_ts_urls(m3u8_obj, url)
            if not ts_urls:
                return None, "未找到TS视频片段"
                
            self.update_status(status_msg, context, f"发现 {len(ts_urls)} 个视频片段，开始下载...")
            
            # 下载TS片段
            ts_files = self._download_ts_files(ts_urls, temp_dir, status_msg, context)
            if not ts_files or len(ts_files) < len(ts_urls) * 0.8:  # 允许最多20%的片段失败
                return None, f"下载TS片段失败，成功 {len(ts_files)}/{len(ts_urls)}"
                
            # 合并TS文件
            self.update_status(status_msg, context, "下载完成，正在合并视频片段...")
            merged_file = os.path.join(temp_dir, "merged.ts")
            if not self._merge_ts_files(ts_files, merged_file):
                return None, "合并视频片段失败"
                
            # 转换为MP4
            self.update_status(status_msg, context, "正在转换为MP4格式...")
            output_file = os.path.join(self.download_dir, f"output_{int(time.time())}.mp4")
            if not self._convert_to_mp4(merged_file, output_file):
                return None, "转换为MP4格式失败"
                
            # 清理临时文件
            for ts_file in ts_files:
                self.delete_file(ts_file)
            self.delete_file(merged_file)
            
            return output_file, "成功"
            
        except Exception as e:
            logger.error(f"下载M3U8出错: {str(e)}")
            return None, str(e)
        finally:
            # 确保临时目录被清理（即使出错）
            if 'temp_dir' in locals() and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, ignore_errors=True)

    def _get_m3u8_playlist(self, url):
        """获取M3U8播放列表对象"""
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            return m3u8.loads(response.text)
        except Exception as e:
            logger.error(f"获取M3U8失败: {str(e)}")
            return None

    def _get_ts_urls(self, m3u8_obj, base_url):
        """从M3U8对象中提取TS文件URL"""
        ts_urls = []
        try:
            # 处理可能的嵌套M3U8
            if m3u8_obj.playlists:
                # 取第一个变体
                playlist = m3u8_obj.playlists[0]
                sub_m3u8_url = urljoin(base_url, playlist.uri)
                sub_m3u8 = self._get_m3u8_playlist(sub_m3u8_url)
                if sub_m3u8:
                    m3u8_obj = sub_m3u8
            
            for segment in m3u8_obj.segments:
                ts_url = urljoin(base_url, segment.uri)
                ts_urls.append(ts_url)
            
            return ts_urls
        except Exception as e:
            logger.error(f"提取TS URL失败: {str(e)}")
            return []

    def _download_ts_files(self, ts_urls, temp_dir, status_msg, context):
        """下载所有TS文件，增加了更健壮的错误处理"""
        ts_files = []
        total = len(ts_urls)
        last_updated = 0
        
        for i, ts_url in enumerate(ts_urls):
            try:
                # 控制状态更新频率，避免请求过于频繁
                current_time = time.time()
                if current_time - last_updated > 1 or i == total - 1:
                    progress = (i + 1) / total * 100
                    self.update_status(
                        status_msg, 
                        context, 
                        f"正在下载 {i+1}/{total} ({progress:.1f}%)"
                    )
                    last_updated = current_time
                
                # 下载TS文件
                ts_filename = f"segment_{i:05d}.ts"
                ts_path = os.path.join(temp_dir, ts_filename)
                
                # 带重试的下载
                retries = 3
                for attempt in range(retries):
                    try:
                        response = self.session.get(ts_url, timeout=10)
                        response.raise_for_status()
                        
                        with open(ts_path, 'wb') as f:
                            f.write(response.content)
                            
                        ts_files.append(ts_path)
                        break  # 下载成功，退出重试循环
                    except Exception as e:
                        logger.warning(f"下载TS片段失败 (尝试 {attempt+1}/{retries}): {str(e)}")
                        if attempt == retries - 1:  # 最后一次尝试失败
                            logger.error(f"无法下载TS片段: {ts_url}")
                        time.sleep(2)  # 重试前等待2秒
                
            except Exception as e:
                logger.error(f"处理TS片段 {i} 时出错: {str(e)}")
                # 继续下载其他片段，但记录错误
                continue
        
        return ts_files

    def _merge_ts_files(self, ts_files, output_path):
        """合并TS文件，提供多种合并方式"""
        try:
            # 确保TS文件按顺序排序
            ts_files.sort()
            
            # 方法1: 使用FFmpeg合并TS文件（首选方法）
            input_streams = [ffmpeg.input(ts_file) for ts_file in ts_files]
            ffmpeg.concat(*input_streams, v=1, a=1).output(output_path).run(overwrite_output=True, quiet=True)
            if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
                return True
                
            # 方法2: 尝试使用FFmpeg的concat协议
            with open(os.path.join(os.path.dirname(output_path), "filelist.txt"), "w") as f:
                for ts_file in ts_files:
                    f.write(f"file '{ts_file}'\n")
            
            ffmpeg.input("filelist.txt", format="concat", safe=0).output(output_path, c="copy").run(overwrite_output=True, quiet=True)
            if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
                return True
                
            # 方法3: 简单拼接文件（备用方法）
            with open(output_path, 'wb') as outfile:
                for ts_file in ts_files:
                    with open(ts_file, 'rb') as infile:
                        outfile.write(infile.read())
            
            return os.path.exists(output_path) and os.path.getsize(output_path) > 0
        except Exception as e:
            logger.error(f"合并TS文件失败: {str(e)}")
            return False

    def _convert_to_mp4(self, input_path, output_path):
        """将TS文件转换为MP4，提供多种转换方式"""
        try:
            # 方法1: 直接复制流（最快）
            ffmpeg.input(input_path).output(
                output_path,
                vcodec='copy',
                acodec='copy',
                format='mp4'
            ).run(overwrite_output=True, quiet=True)
            
            if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
                return True
                
            # 方法2: 重新编码（兼容性更好）
            ffmpeg.input(input_path).output(
                output_path,
                vcodec='libx264',
                acodec='aac',
                format='mp4',
                crf=23,  # 质量控制，值越小质量越高
                preset='medium'
            ).run(overwrite_output=True, quiet=True)
            
            return os.path.exists(output_path) and os.path.getsize(output_path) > 0
        except Exception as e:
            logger.error(f"转换为MP4失败: {str(e)}")
            return False
