import os
import logging
import time
import psutil
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackQueryHandler, CallbackContext
from m3u8_downloader import M3U8Downloader
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 配置日志
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# 初始化下载器
DOWNLOAD_DIR = os.getenv('DOWNLOAD_DIR', '/app/downloads')
downloader = M3U8Downloader(DOWNLOAD_DIR)

# 生成按钮
def get_main_keyboard():
    keyboard = [
        [InlineKeyboardButton("📚 使用帮助", callback_data='help')],
        [InlineKeyboardButton("ℹ️ 关于机器人", callback_data='about')],
        [InlineKeyboardButton("🧹 清除缓存", callback_data='clean_cache')],
        [InlineKeyboardButton("📊 检查状态", callback_data='status')]
    ]
    return InlineKeyboardMarkup(keyboard)

def start(update: Update, context: CallbackContext) -> None:
    """发送欢迎消息和按钮"""
    user = update.effective_user
    # 修复MarkdownV2格式，转义所有特殊字符
    update.message.reply_markdown_v2(
        fr'你好 {user.mention_markdown_v2()}! \👋'  # 转义感叹号
        '\n请发送一个M3U8视频链接，我会帮你下载并发送回来。',
        reply_markup=get_main_keyboard()
    )

def button_handler(update: Update, context: CallbackContext) -> None:
    """处理按钮点击"""
    query = update.callback_query
    query.answer()  # 确认收到回调

    # 根据按钮回调数据执行不同操作
    if query.data == 'help':
        help_text = (
            "📚 使用帮助：\n"
            "1. 直接发送M3U8视频链接（包含http://或https://）\n"
            "2. 机器人会自动下载、合并并发送视频\n"
            "3. 支持的格式：.m3u8\n"
            "4. 注意：文件大小不能超过50MB（Telegram限制）\n"
            "5. 受版权保护或需要登录的视频无法下载"
        )
        query.edit_message_text(text=help_text, reply_markup=get_main_keyboard())
        
    elif query.data == 'about':
        about_text = (
            "ℹ️ 关于机器人：\n"
            "版本：1.1.0\n"
            "功能：下载M3U8视频并发送到Telegram\n"
            "特点：\n"
            "- 自动合并视频片段\n"
            "- 显示下载/上传进度\n"
            "- 自动清理本地文件\n"
            "- 支持缓存管理"
        )
        query.edit_message_text(text=about_text, reply_markup=get_main_keyboard())
        
    elif query.data == 'clean_cache':
        try:
            cleaned_size = downloader.clean_expired_files()
            query.edit_message_text(
                text=f"🧹 缓存清理完成\n已删除过期文件：{cleaned_size:.2f} MB",
                reply_markup=get_main_keyboard()
            )
        except Exception as e:
            query.edit_message_text(
                text=f"清理失败：{str(e)}",
                reply_markup=get_main_keyboard()
            )
            
    elif query.data == 'status':
        # 获取系统状态
        cpu_usage = psutil.cpu_percent(interval=1)
        mem_usage = psutil.virtual_memory().percent
        disk_usage = psutil.disk_usage('/').percent
        cache_size = downloader.get_cache_size()
        
        status_text = (
            "📊 系统状态：\n"
            f"CPU使用率：{cpu_usage}%\n"
            f"内存使用率：{mem_usage}%\n"
            f"磁盘使用率：{disk_usage}%\n"
            f"当前缓存大小：{cache_size:.2f} MB"
        )
        query.edit_message_text(text=status_text, reply_markup=get_main_keyboard())

def handle_message(update: Update, context: CallbackContext) -> None:
    """处理收到的消息，检查是否为M3U8链接"""
    message = update.effective_message
    text = message.text or message.caption
    
    if not text:
        message.reply_text('请发送文本消息，包含M3U8链接。', reply_markup=get_main_keyboard())
        return
    
    # 检查是否为M3U8链接
    if 'm3u8' in text and ('http://' in text or 'https://' in text):
        process_m3u8_link(update, context, text)
    else:
        message.reply_text('请发送有效的M3U8视频链接（包含http://或https://和m3u8）。', reply_markup=get_main_keyboard())

def process_m3u8_link(update: Update, context: CallbackContext, url: str) -> None:
    """处理M3U8链接：下载、转换、上传、删除"""
    message = update.effective_message
    chat_id = update.effective_chat.id
    
    try:
        # 发送开始处理的消息
        status_msg = message.reply_text('开始处理M3U8视频链接...', reply_markup=get_main_keyboard())
        
        # 下载并处理M3U8视频
        video_path, status = downloader.download_m3u8(url, status_msg, context)
        
        if not video_path:
            status_msg.edit_text(f'处理失败: {status}', reply_markup=get_main_keyboard())
            return
        
        # 检查文件大小（Telegram对免费用户有50MB限制）
        file_size = os.path.getsize(video_path)
        file_size_mb = file_size / (1024 * 1024)
        
        if file_size_mb > 50:
            status_msg.edit_text(
                f'视频文件太大（{file_size_mb:.2f}MB），超过Telegram免费用户50MB限制，无法上传。',
                reply_markup=get_main_keyboard()
            )
            # 自动删除过大的文件
            downloader.delete_file(video_path)
            return
        
        # 上传视频
        status_msg.edit_text(f'下载完成，正在上传视频（{file_size_mb:.2f}MB）...')
        
        # 发送视频（带进度条）
        from telegram.error import TelegramError
        try:
            # 使用进度条上传
            with open(video_path, 'rb') as video_file:
                message.reply_video(
                    video=video_file,
                    caption='视频处理完成，已自动删除本地文件。',
                    timeout=600  # 延长超时时间
                )
        except TelegramError as e:
            status_msg.edit_text(f'上传失败: {str(e)}', reply_markup=get_main_keyboard())
            downloader.delete_file(video_path)
            return
        
        # 上传成功后删除本地文件
        downloader.delete_file(video_path)
        
        # 更新状态消息
        status_msg.edit_text('视频已成功发送，并已删除本地文件。', reply_markup=get_main_keyboard())
        
    except Exception as e:
        logger.error(f'处理M3U8时出错: {str(e)}')
        message.reply_text(f'处理过程中出错: {str(e)}', reply_markup=get_main_keyboard())

def main() -> None:
    """启动机器人"""
    TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
    if not TOKEN:
        logger.error('未设置TELEGRAM_BOT_TOKEN环境变量')
        return
    
    updater = Updater(TOKEN)
    
    dispatcher = updater.dispatcher
    
    # 注册错误处理器
    def error_handler(update: Update, context: CallbackContext) -> None:
        """记录所有错误"""
        logger.error(msg="Exception while handling an update:", exc_info=context.error)
    
    dispatcher.add_error_handler(error_handler)
    
    # 注册命令处理器
    dispatcher.add_handler(CommandHandler("start", start))
    
    # 注册按钮处理器
    dispatcher.add_handler(CallbackQueryHandler(button_handler))
    
    # 注册消息处理器
    dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))
    dispatcher.add_handler(MessageHandler(Filters.caption & ~Filters.command, handle_message))
    
    # 启动机器人
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
